package com.example.focusguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

private const val IG = "com.instagram.android"

private val TAB_BAR_IDS = listOf("tab_bar", "bottom_tab_bar")
private val HOME_TAB_IDS = listOf("feed_tab", "home_tab")
private val SEARCH_TAB_IDS = listOf("search_tab", "search_tab_button")
private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
private val DIRECT_TAB_IDS = listOf(
    "direct_tab", "direct_tab_button", "action_bar_inbox", "inbox_tab", "messenger_tab"
)
private val SEARCH_BOX_IDS = listOf("action_bar_search_edit_text", "search_edit_text")
private val REEL_PLAYER_IDS = listOf(
    "reel_recycler", "reel_player_page_container", "clips_view_pager", "reel_viewer_root"
)

private val DARK_BG = 0xFF0C0F14.toInt()
private val LIGHT_BG = 0xFFFFFFFF.toInt()

data class Colors(val bg: Int, val text: Int, val sub: Int, val accent: Int)

object Palette {
    private val LIGHT = Colors(LIGHT_BG, 0xFF262626.toInt(), 0xFF737373.toInt(), 0xFF0095F6.toInt())
    private val DARK = Colors(DARK_BG, 0xFFFAFAFA.toInt(), 0xFFA8A8A8.toInt(), 0xFF0095F6.toInt())

    fun now(c: Context): Colors {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val saver = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return if (night || saver) DARK else LIGHT
    }
}

object Quotes {
    val full = listOf(
        "You came here for a reason. Go do that.",
        "Your time is the one thing you can't scroll back.",
        "Be where your feet are.",
        "Close the feed. Open your day.",
        "Nothing here is as good as what you're about to do."
    )
    val tile = listOf("Focus", "Be here", "Not now", "Breathe")
}

class GuardService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private val views = HashMap<String, View>()
    private val rects = HashMap<String, Rect>()

    private var pending = false
    private var instagramSessionActive = false
    private var watchdogRunning = false
    private val instagramWatchdog = object : Runnable {
        override fun run() {
            if (!instagramSessionActive || !::wm.isInitialized) {
                watchdogRunning = false
                return
            }

            val root = rootInActiveWindow
            if (root?.packageName?.toString() != IG) {
                instagramSessionActive = false
                watchdogRunning = false
                hideAll()
                return
            }

            // Keep evaluating for the entire time Instagram remains the active app.
            // Accessibility events provide immediate reactions; this watchdog is the
            // continuous fallback for UI changes that do not emit a useful event.
            evaluate()
            ui.postDelayed(this, 200L)
        }
    }

    private var lastDirectAt = 0L
    private var lastScreenWasDirect = false
    private var lastRootHash = 0

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Evaluate immediately, then again after Instagram has finished laying out its first frame.
        evaluate()
        ui.postDelayed({ evaluate() }, 16L)
        ui.postDelayed({ evaluate() }, 80L)
        ui.postDelayed({ evaluate() }, 180L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName != IG) return

        instagramSessionActive = true
        startWatchdog()

        val important = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED

        if (!pending) {
            pending = true
            ui.postDelayed({
                pending = false
                evaluate()
            }, if (important) 0L else 4L)
        }
    }

    override fun onInterrupt() = hideAll()

    override fun onDestroy() {
        instagramSessionActive = false
        ui.removeCallbacks(instagramWatchdog)
        watchdogRunning = false
        hideAll()
        super.onDestroy()
    }

    private fun startWatchdog() {
        if (watchdogRunning || !::wm.isInitialized) return
        watchdogRunning = true
        ui.removeCallbacks(instagramWatchdog)
        ui.post(instagramWatchdog)
    }

    private fun evaluate() {
        if (!::wm.isInitialized) return

        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != IG) {
            instagramSessionActive = false
            ui.removeCallbacks(instagramWatchdog)
            watchdogRunning = false
            hideAll()
            return
        }

        val rawScreen = bounds(root)
        val screen = usableScreen(rawScreen)
        val bottomNavTop = findBottomNavTop(root, screen)
        val contentBottom = minOf(bottomNavTop, screen.bottom)

        val homeSelected = isSelected(root, HOME_TAB_IDS)
        val search = isSelected(root, SEARCH_TAB_IDS) || first(root, SEARCH_BOX_IDS)?.isFocused == true ||
            looksLikeSearch(root)
        val reels = isSelected(root, REELS_TAB_IDS) || looksLikeReels(root)
        val direct = isDirectScreen(root)
        val profile = isProfile(root)
        val reelOpen = !profile && REEL_PLAYER_IDS.any { find(root, it) != null }
        val home = !search && !reels && !direct && !profile &&
            (homeSelected || looksLikeHome(root, rawScreen))

        val now = System.currentTimeMillis()
        if (direct) {
            lastDirectAt = now
            lastScreenWasDirect = true
        } else if (home || search || reels || profile) {
            lastScreenWasDirect = false
        }

        val sharedViewer = !direct && lastScreenWasDirect &&
            now - lastDirectAt < 7000L && reelOpen

        if (search) {
            hideAllExcept("full")
            show("full", Rect(rawScreen.left, rawScreen.top, rawScreen.right, contentBottom), quoteFor("search"), 22f)
            return
        }

        if (reels || (reelOpen && !sharedViewer)) {
            hideAllExcept("full")
            show("full", Rect(rawScreen.left, rawScreen.top, rawScreen.right, contentBottom), quoteFor("reels"), 22f)
            return
        }

        if (sharedViewer) {
            hideAllExcept("sharedGesture")
            // The shared item can be viewed, but the viewer cannot be swiped to another item.
            // Taps are replayed; all swipes are consumed.
            val viewer = findViewerRect(root, rawScreen)
            showGesture("sharedGesture", viewer, horizontalAllowed = false)
            return
        }

        hide("sharedGesture")
        hide("full")
        hide("tile")

        if (home) {
            val story = findStoryRect(root, rawScreen)
            val storyRect = story ?: fallbackStoryRect(rawScreen)

            // Only the actual Stories row receives the gesture gate. Nothing above it is covered.
            val storyGate = Rect(
                rawScreen.left,
                storyRect.top.coerceAtLeast(rawScreen.top),
                rawScreen.right,
                storyRect.bottom.coerceAtMost(contentBottom)
            )
            if (storyGate.height() > dp(30)) {
                showGesture("stories", storyGate, horizontalAllowed = true)
            } else {
                hide("stories")
            }

            // Hide the feed immediately on the first Home evaluation, beginning exactly after Stories.
            val feedTop = storyRect.bottom.coerceAtLeast(rawScreen.top)
            if (contentBottom > feedTop + dp(8)) {
                showBlank("feed", Rect(rawScreen.left, feedTop, rawScreen.right, contentBottom))
            } else {
                hide("feed")
            }
        } else {
            hide("stories")
            hide("feed")
        }

        if (profile) {
            // Preserve the entire profile header. The protected region starts at the
            // transition into Highlights / Posts / Reels / Tagged content.
            val top = profileProtectedTop(root, rawScreen)
            if (contentBottom > top + dp(8)) {
                showBlank("profile", Rect(rawScreen.left, top, rawScreen.right, contentBottom))
            } else {
                hide("profile")
            }
        } else {
            hide("profile")
        }

        val reelsTab = first(root, REELS_TAB_IDS)
        if (reelsTab != null && !reels) {
            show("tile", bounds(reelsTab), Quotes.tile[(System.currentTimeMillis() / 5000L).toInt() % Quotes.tile.size], 9f)
        } else {
            hide("tile")
        }

        lastRootHash = root.hashCode()
    }

    private fun quoteFor(page: String): String {
        val index = ((System.currentTimeMillis() / 7000L).toInt() + page.hashCode()).let { abs(it) % Quotes.full.size }
        return Quotes.full[index]
    }

    private fun isProfile(root: AccessibilityNodeInfo): Boolean {
        val hasFollowers = containsText(root, listOf("Followers"))
        val hasFollowing = containsText(root, listOf("Following"))
        val hasProfileAction = containsText(root, listOf("Follow", "Message", "Edit profile"))
        return (hasFollowers && hasFollowing && hasProfileAction) ||
            (hasFollowers && hasFollowing && containsText(root, listOf("Posts", "Reels", "Tagged")))
    }

    private fun profileProtectedTop(root: AccessibilityNodeInfo, screen: Rect): Int {
        val headerRects = mutableListOf<Rect>()
        collectTextRects(
            root,
            listOf(
                "Followers", "Following", "Follow", "Following", "Message", "Edit profile",
                "Share profile", "Subscribed", "Contact", "Bio"
            ),
            headerRects
        )

        val tabRects = mutableListOf<Rect>()
        collectTextRects(root, listOf("Posts", "Reels", "Tagged", "Tagged posts"), tabRects)

        val highlightRects = mutableListOf<Rect>()
        collectTextRects(
            root,
            listOf("Highlights", "Highlight", "Add highlight", "New highlight"),
            highlightRects
        )

        val tabTop = tabRects.filter { it.top > screen.top + dp(120) }.minByOrNull { it.top }?.top
        val highlightTop = highlightRects.filter { it.top > screen.top + dp(120) }.minByOrNull { it.top }?.top
        val headerBottom = headerRects.filter { it.top > screen.top + dp(90) }.maxByOrNull { it.bottom }?.bottom

        // If Instagram exposes a Highlights node, hide from its row upward edge.
        if (highlightTop != null) return (highlightTop - dp(20)).coerceAtLeast(screen.top)

        // Otherwise use the real profile metadata boundary, then protect everything below it.
        // Keep a small gap so the final header text remains visible.
        if (headerBottom != null) {
            val candidate = headerBottom + dp(52)
            return if (tabTop != null) minOf(candidate, tabTop - dp(18)) else candidate
        }

        if (tabTop != null) {
            // No explicit header controls found. Keep the header above the tab strip visible.
            return (tabTop - dp(90)).coerceAtLeast(screen.top)
        }

        return (screen.top + screen.height() * 0.38f).toInt()
    }

    private fun findStoryRect(root: AccessibilityNodeInfo, screen: Rect): Rect? {
        val named = listOf("reel_tray_container", "stories_tray", "story_tray", "row_feed_story")
            .asSequence()
            .mapNotNull { find(root, it) }
            .map { bounds(it) }
            .filter { it.width() > screen.width() * .55 && it.top < screen.height() * .45 }
            .maxByOrNull { it.bottom }

        if (named != null) {
            return Rect(screen.left, named.top, screen.right, named.bottom)
        }

        // Fallback for Instagram builds where the tray's resource id changes.
        val storyNodes = mutableListOf<Rect>()
        collectTextRects(root, listOf("Your story", "story", "stories"), storyNodes)
        val candidates = storyNodes.filter {
            it.top > screen.top + dp(60) && it.top < screen.top + screen.height() * .42
        }
        if (candidates.isNotEmpty()) {
            val top = candidates.minOf { it.top } - dp(42)
            val bottom = candidates.maxOf { it.bottom } + dp(54)
            return Rect(screen.left, top, screen.right, bottom)
        }

        return null
    }

    private fun fallbackStoryRect(screen: Rect): Rect {
        // Conservative fallback used only while Instagram's story tray has not exposed
        // its accessibility nodes yet. It leaves the top header untouched.
        val top = screen.top + (screen.height() * 0.12f).toInt()
        val bottom = screen.top + (screen.height() * 0.26f).toInt()
        return Rect(screen.left, top, screen.right, minOf(bottom, screen.bottom))
    }

    private fun findViewerRect(root: AccessibilityNodeInfo, screen: Rect): Rect {
        val viewer = REEL_PLAYER_IDS.asSequence().mapNotNull { find(root, it) }.map { bounds(it) }
            .firstOrNull { it.width() > screen.width() * .55 && it.height() > dp(250) }
        return viewer ?: Rect(screen.left, screen.top + dp(70), screen.right, screen.bottom)
    }

    private fun looksLikeSearch(root: AccessibilityNodeInfo): Boolean {
        return containsText(root, listOf("Search Instagram", "Search")) &&
            !containsText(root, listOf("Followers", "Following"))
    }

    private fun looksLikeReels(root: AccessibilityNodeInfo): Boolean {
        return containsText(root, listOf("Reels")) &&
            (REEL_PLAYER_IDS.any { find(root, it) != null } || containsText(root, listOf("Share", "Comment")))
    }

    private fun looksLikeHome(root: AccessibilityNodeInfo, screen: Rect): Boolean {
        return findStoryRect(root, screen) != null && first(root, REELS_TAB_IDS) != null
    }

    private fun isDirectScreen(root: AccessibilityNodeInfo): Boolean = isSelected(root, DIRECT_TAB_IDS)

    private fun findBottomNavTop(root: AccessibilityNodeInfo, screen: Rect): Int {
        val tabBar = first(root, TAB_BAR_IDS)
        if (tabBar != null) {
            val r = bounds(tabBar)
            if (r.top > screen.top + dp(300)) return r.top
        }

        val navLabels = mutableListOf<Rect>()
        collectTextRects(root, listOf("Home", "Reels", "Search", "Profile", "Messages"), navLabels)
        val lower = navLabels.filter { it.top > screen.top + screen.height() * .65f }
        if (lower.isNotEmpty()) return lower.minOf { it.top } - dp(20)

        // Android's system navigation bar is also excluded from our overlay geometry.
        // Keep a conservative bottom strip free when Instagram does not expose the tab bar.
        return screen.bottom - (screen.height() * 0.11f).toInt()
    }

    private fun hideAllExcept(keep: String) {
        views.keys.toList().forEach { if (it != keep) hide(it) }
    }

    private inner class GestureGate(context: Context, private val horizontalAllowed: Boolean) : View(context) {
        private var downX = 0f
        private var downY = 0f
        private var moved = false
        private val threshold = dp(10)

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.rawX - downX) > threshold || abs(event.rawY - downY) > threshold) {
                        moved = true
                    }
                    return true
                }

                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!moved) {
                        replayTap(event.rawX, event.rawY)
                    } else if (horizontalAllowed && abs(dx) > abs(dy) && abs(dx) > threshold) {
                        // Stories: allow left/right story navigation only.
                        replaySwipe(downX, downY, event.rawX, event.rawY)
                    }
                    // Vertical swipes are intentionally consumed.
                    return true
                }

                MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    private fun replayTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun replaySwipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 180)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun containsText(node: AccessibilityNodeInfo?, values: List<String>): Boolean {
        if (node == null || !node.isVisibleToUser) return false
        val hay = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (values.any { hay.contains(it, true) }) return true
        for (i in 0 until node.childCount) {
            if (containsText(node.getChild(i), values)) return true
        }
        return false
    }

    private fun collectTextRects(node: AccessibilityNodeInfo?, labels: List<String>, out: MutableList<Rect>) {
        if (node == null || !node.isVisibleToUser) return
        val text = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (labels.any { text.equals(it, true) || text.contains(it, true) }) out.add(bounds(node))
        for (i in 0 until node.childCount) collectTextRects(node.getChild(i), labels, out)
    }

    private fun isSelected(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.asSequence().mapNotNull { find(root, it) }.any { it.isSelected }

    private fun first(root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? =
        ids.asSequence().mapNotNull { find(root, it) }.firstOrNull()

    private fun find(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId("$IG:id/$name").firstOrNull { it.isVisibleToUser }

    private fun bounds(node: AccessibilityNodeInfo): Rect = Rect().also { node.getBoundsInScreen(it) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun usableScreen(r: Rect): Rect {
        val nav = resources.getIdentifier("navigation_bar_height", "dimen", "android").let {
            if (it != 0) resources.getDimensionPixelSize(it) else dp(24)
        }
        return Rect(r.left, r.top, r.right, (r.bottom - nav).coerceAtLeast(r.top + dp(200)))
    }

    private fun showGesture(key: String, rect: Rect, horizontalAllowed: Boolean) {
        if (rect.width() <= 0 || rect.height() <= 0) {
            hide(key)
            return
        }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != rect) wm.updateViewLayout(existing, params(rect))
            } else {
                val view = GestureGate(this, horizontalAllowed)
                wm.addView(view, params(rect))
                views[key] = view
            }
            rects[key] = rect
        } catch (_: Exception) {
        }
    }

    private fun showBlank(key: String, rect: Rect) {
        if (rect.width() <= 0 || rect.height() <= 0) {
            hide(key)
            return
        }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != rect) wm.updateViewLayout(existing, params(rect))
            } else {
                val view = buildBlank()
                wm.addView(view, params(rect))
                views[key] = view
            }
            rects[key] = rect
        } catch (_: Exception) {
        }
    }

    private fun buildBlank(): View = View(this).apply {
        setBackgroundColor(Palette.now(context).bg)
        isClickable = true
        setOnTouchListener { _, _ -> true }
    }

    private fun show(key: String, rect: Rect, message: String, textSize: Float) {
        if (rect.width() <= 0 || rect.height() <= 0) {
            hide(key)
            return
        }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != rect) wm.updateViewLayout(existing, params(rect))
                (existing as? LinearLayout)?.let { layout ->
                    (layout.getChildAt(0) as? TextView)?.text = message
                }
            } else {
                val view = buildMessage(message, textSize)
                wm.addView(view, params(rect))
                views[key] = view
            }
            rects[key] = rect
        } catch (_: Exception) {
        }
    }

    private fun buildMessage(message: String, textSize: Float): View {
        val colors = Palette.now(this)
        val padding = dp(if (textSize > 12f) 32 else 2)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(colors.bg)
            setPadding(padding, 0, padding, 0)
            isClickable = true
            setOnTouchListener { _, _ -> true }
            addView(TextView(context).apply {
                text = message
                this.textSize = textSize
                gravity = Gravity.CENTER
                setTextColor(colors.text)
            })
        }
    }

    private fun hide(key: String) {
        rects.remove(key)
        views.remove(key)?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
    }

    private fun hideAll() = views.keys.toList().forEach { hide(it) }

    private fun params(rect: Rect) = WindowManager.LayoutParams(
        rect.width(),
        rect.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = rect.left
        y = rect.top
    }
}
