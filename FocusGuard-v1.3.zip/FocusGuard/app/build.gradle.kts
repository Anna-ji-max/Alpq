plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.focusguard"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.focusguard"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.3"
    }
}

kotlin { jvmToolchain(17) }
