# FocusGuard

FocusGuard is an Android AccessibilityService prototype for reducing Instagram browsing distractions while leaving communication features available.

## v1.3 behavior
- Home: hides the feed immediately below Stories; the Instagram bottom navigation is left uncovered.
- Stories: taps and left/right swipes are allowed; vertical swipes are consumed.
- Search: stays on Search and shows a focus message instead of redirecting Home.
- Reels: stays on Reels and shows a focus message; Reels navigation is blocked.
- Profiles: preserves the profile header and starts the protected area at the transition into Highlights/content; bottom navigation stays uncovered.
- DM-shared Reel/Post: the opened item can be viewed and tapped, but swiping to another item is blocked.
- Light/dark and power-saver colors follow the device configuration.
- Evaluation is triggered immediately on service connection and Instagram window/content changes, and a continuous 200 ms foreground watchdog keeps re-checking while Instagram remains the active app. The watchdog stops when Instagram is no longer the active app, so it does not keep polling after Instagram is closed or left.

The service uses Android AccessibilityService window-content access, accessibility overlays, and gesture dispatch. Android requires the user to explicitly enable an accessibility service in system settings.

## Build
The repository includes `.github/workflows/build-apk.yml` for a GitHub Actions debug build using Android SDK 35, JDK 17, and Gradle 8.10.

## Package
`com.example.focusguard`
